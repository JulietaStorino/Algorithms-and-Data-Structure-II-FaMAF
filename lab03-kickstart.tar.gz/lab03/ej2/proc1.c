#include <stdlib.h>
#include <stdio.h>

void absolute(int x, int y) {
    //
    // Completar aquí
    //
}

int main(void) {
    int a=0, res=0;
    //
    // Completar aquí
    //
    return EXIT_SUCCESS;
}

